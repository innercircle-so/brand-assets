NulTien is a display typeface inspired by the architecture and the culture of Rotterdam. 
Designed by Constantine Belias, this font is a study on typography and the city's structural forms. 
Use it in Regular and Bold weights, alongside with italics, including numbers and symbols (future updates will include a more complete glyph set), and a version called "Techno", envisioned by the vibe of the evolving Rotterdam.

The font is completely free to download and use over any kind of visual communication, commercial or not, carriers of art, pillars of culture, venues, etc. Feel free to experiment, distort, stretch and use in any creative way.

All works using this font would be nice to include the #NulTienFont hashtag, so as to keep them in track.

Visit:
https://nultien.xyz/

https://constantine.digital/